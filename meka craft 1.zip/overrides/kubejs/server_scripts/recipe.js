/*
    こんにちは
    書き換えは自由です　再配布は禁止
    コードが汚いのは許してください
    一番下にテンプレート載せます　どうぞご自由に

*/ 

ServerEvents.recipes(event => {
    event.remove({output:'mekanism:digital_miner'})
    event.remove({ output: 'mekanism:creative_bin' })
    event.remove({ output: 'mekanism:module_base' })
    event.remove({ output: 'mekanismgenerators:solar_generator' })    
    event.remove({ output: 'mekanismgenerators:solar_panel' })
    event.remove({ output: 'mekanismgenerators:fission_fuel_assembly' })
    event.remove({ output: 'mekanismgenerators:advanced_solar_generator' })
    event.remove({ output: 'mekanism:metallurgic_infuser' })
    event.remove({ output: 'mekanism:teleportation_core' })
    event.remove({ output: 'mekanism:atomic_disassembler' })
    event.remove({ output: 'mekanism:teleporter_frame' })
    event.remove({ output: 'mekanism:quantum_entangloporter' })
    event.remove({ output: 'mekanism:portable_teleporter' })
    event.remove({ output: 'igleelib:iglium_upgrade_smithing_template' })
    //嫌いな虫食いブロック  こいつらのせいで120点のゲームが99点になってる 史上最悪のブロック
    event.remove({ output: 'minecraft:infested_stone' })//#虫食いブロックを許すな  
    event.remove({ output: 'minecraft:infested_cobblestone' })//二度と出てくるな　さっさと消えやがれ　
    event.remove({ output: 'minecraft:infested_stone_bricks' })//要塞に出てくるな！！！
    event.remove({ output: 'minecraft:infested_cracked_stone_bricks' })//山にも出てくるな！！！１
    event.remove({ output: 'minecraft:infested_mossy_stone_bricks' })//こいつらに何度やられたことか！！！
    event.remove({ output: 'minecraft:infested_chiseled_stone_bricks' })//石造りの家をこいつらに汚染されたし！！！
    event.remove({ output: 'minecraft:infested_deepslate' })//直下掘りしてきたら出てきて殺されたし！！！
    event.remove({ output: 'mekanism:reprocessed_fissile_fragment' })
    event.remove({ id: "create:splashing/soul_sand" })
    event.remove({ output: 'mekanismelements:high_performance_adsorbent_beryllium' })

}
)



ServerEvents.recipes(event => {
  



  event.recipes.create.splashing(
    [
      Item.of('minecraft:quartz', 10),
      Item.of('minecraft:gold_ingot', 10)
    ],
    'minecraft:soul_sand'
  )



  




  // デジタルマイナー

event.recipes.create.mechanical_crafting(
    'mekanism:digital_miner',
    [
      "ABGBA",
      "BGIGB",
      "GJKJG",
      "BGHGB",
      "ABGBA"
    ],
    {
      A: 'mekanism:ultimate_control_circuit',
      B: 'mekanism:alloy_atomic',
      
      

      G: 'mekanism:steel_casing',
      H: 'mekanism:teleportation_core',
      I: 'mekanism:advanced_energy_cube',
      J: 'mekanism:logistical_sorter',
      K: 'mekanism:robit'
    }
  )


  event.recipes.create.mechanical_crafting(
    'mekanism:teleporter',
    [
      "CCACC",
      "CABAC",
      "ABABA",
      "CABAC",
      "CCACC"
    ],
    {
      A: 'evolvedmekanism:quantum_control_circuit',
      C: 'mekanism:block_refined_obsidian',
      B: 'mekanism:teleportation_core',
    }
  )
  // クリエイティブビン

event.recipes.create.mechanical_crafting(
    'mekanism:creative_bin',
    [
      "AAAAAAAAA",
      "AAAAAAAAA",
      "AAAAAAAAA",
      "AAAAAAAAA",
      "AAAAAAAAA",
      "AAAAAAAAA",
      "AAABEBAAA",
      "AAACDCAAA",
      "AAABBBAAA",



   
    ],
    {
      A: 'evolvedmekanism:block_alloy_creative',
      B: 'compressedblocks:c9_netherite_block',
      C: 'evolvedmekanism:qio_drive_creative',
      D: 'evolvedmekanism:multiversal_bin',
      E: 'evolvedmekanism:creative_induction_cell',
      

      
    }

    
      
)  



   
    event.recipes.mekanism.injecting(
        '14x mekanism:reprocessed_fissile_fragment', 
        'mekanism:pellet_plutonium', 
        { gas: 'mekanism:oxygen', amount: 1 }
    )


    event.recipes.mekanism.injecting(
        'minecraft:copper_ingot', 
        'minecraft:prismarine_shard', 
        { gas: 'mekanism:oxygen', amount: 100 }
    )

event.recipes.create.mechanical_crafting(
    'mekanism:quantum_entangloporter',
    [
      "AABBAA",
      "AACCAA",
      "BCCCCB",
      "BCCCCB",
      "AACCAA",
      "AABBAA",

    ],
    {
      A: 'mekanism:block_refined_obsidian',
      B: 'evolvedmekanism:quantum_control_circuit',
      C: 'mekanism:teleportation_core',
}
)  

  event.shaped('mekanism:chargepad', [
    '   ',
    'BBB',
    'ACA'
  ], {
    A: 'mekanism:ingot_steel',
    B: 'minecraft:blackstone',
    C: 'mekanism:energy_tablet',

    
  })
  





//モジュールベース


  event.shaped('8x mekanism:module_base', [
    'ABA',
    'BCB',
    'ABA'
  ], {
    A: 'mekanism:enriched_gold',
    B: 'mekanism:pellet_polonium',
    C: 'mekanism:hdpe_sheet',

    
  })

    event.shaped('mekanism:portable_teleporter', [
    ' B ',
    'ACA',
    ' B '
  ], {
    A: 'mekanism:ultimate_induction_cell',
    B: 'evolvedmekanism:quantum_control_circuit',
    C: 'mekanism:teleportation_core',

    
  })

  event.shaped('mekmm:advanced_electrolysis_core', [
    ' B ',
    ' C ',
    ' B '
  ], {
    B: 'mekanism:electrolytic_core',
    C: 'evolvedmekanism:alloy_hypercharged',

    
  })


  event.shaped('9x mekanismgenerators:fission_fuel_assembly', [
    'ABA',
    'ACA',
    'ABA',
  ], {
    A: 'mekanism:block_lead',
    B: 'mekanism:block_steel',
    C: 'mekanism:block_osmium',

    
  })
    
  event.shapeless(
    'minecraft:white_wool', 
    [
  
    '4x minecraft:andesite'
    ]


    
  )

  event.shaped('buildinggadgets2:gadget_destruction', [
    'ABA',
    'CBC',
    'ADA'
  ], {
    A: 'minecraft:iron_ingot',
    B: 'minecraft:redstone',
    C: 'minecraft:diamond_pickaxe',
    D: 'minecraft:lapis_lazuli'
  })



  event.shapeless(
    'mekanism:sawdust', 
    [
  
    '#minecraft:wooden_buttons'
    ]


    
  )
//ソーラーパネル
  event.shaped('mekanismgenerators:solar_panel', [
    ' A ',
    ' B ',
    ' C '
  ], {
    A: 'minecraft:glass_pane',
    B: 'mekanism:alloy_infused',
    C: 'mekanism:ingot_osmium',
  })//太陽光発電機
  event.shaped('mekanismgenerators:solar_generator', [
    ' A ',
    ' B ',
    ' C '
  ], {
    A: 'mekanismgenerators:solar_panel',
    B: 'mekanism:alloy_infused',
    C: 'mekanism:energy_tablet',

  })//発展型太陽光発電機
   event.shaped('mekanismgenerators:advanced_solar_generator', [
    'ABA',
    ' C ',
    'DDD'
  ], {
    A: 'mekanismgenerators:solar_generator',
    B: 'mekanism:alloy_infused',
    C: 'mekanism:ingot_osmium',
    D: 'minecraft:iron_ingot',
  })
//テレポーターフレーム
  event.shaped('mekanism:teleporter_frame', [
    'AAA',
    'ABA',
    'AAA'
  ], {
    A: 'mekanism:pellet_antimatter',
    B: 'mekanism:block_refined_obsidian',
   
    
  })

  event.shaped('mekanism:atomic_disassembler', [//原子分解機
    'ABA',
    'ACA',
    ' D '
  ], {
    A: 'mekanism:alloy_reinforced',
    B: 'mekanism:basic_energy_cube',
    C: 'mekanism:alloy_atomic',
    D: 'mekanism:ingot_refined_obsidian'
   
    
  })


//テレポーテーションコア
event.shaped('mekanism:teleportation_core', [
    'ABA',
    'BCB',
    'ABA'
  ], {
    A: 'mekanism:ultimate_control_circuit',
    B: 'mekanism:alloy_atomic',
    C: 'minecraft:diamond',
  
  })

})

ServerEvents.recipes(event => {

  const incomplete = 'minecraft:iron_block'



  event.recipes.create.sequenced_assembly(
    ['mekanism:metallurgic_infuser'],
    'minecraft:iron_block',
    [
      event.recipes.create.deploying(incomplete, [incomplete, 'minecraft:redstone_block']),
      event.recipes.create.deploying(incomplete, [incomplete, 'mekanism:block_osmium']),
      event.recipes.create.pressing(incomplete, incomplete),
      event.recipes.create.deploying(incomplete, [incomplete, 'create:brass_casing'])
    ]
  )
  .id('kubejs:infuser_assembly')
  .transitionalItem(incomplete)
  .loops(1)

})

ServerEvents.recipes(event => {
  const incomplete = 'mekanism:block_osmium'//クリエイティブ合金

  

  event.recipes.create.sequenced_assembly(
    ['evolvedmekanism:alloy_creative'],
    'compressedblocks:c9_iron_block',
    [
      event.recipes.create.deploying(incomplete, [incomplete, 'evolvedmekanism:block_alloy_exoversal']),
      event.recipes.create.deploying(incomplete, [incomplete, 'evolvedmekanism:block_alloy_exoversal']),
      event.recipes.create.deploying(incomplete, [incomplete, 'mekmm:uu_matter']),
      event.recipes.create.filling(incomplete,[incomplete, Fluid.of('evolvedmekanism:molten_plaslitherite', 999)]),
      event.recipes.create.pressing(incomplete, incomplete),
   
    ]
  )
  
  .transitionalItem(incomplete)
  .loops(99)
  .id('kubejs:creative_alloy_assembly')

})




ServerEvents.recipes(event => {

  event.custom({
    type: "mekanism:reaction",

    itemInput: {
      ingredient: {
        item: "create:brass_ingot"
      }
    },

    fluidInput: {
      fluid: "minecraft:lava",
      amount: 1000
    },

    gasInput: {
      gas: "mekanism:superheated_sodium",
      amount: 1000
    },

    energyRequired: 1000,
    duration: 1,

    itemOutput: {
      item: "minecraft:netherite_ingot"
    },

    gasOutput: {
      gas: "mekanism:sodium",
      amount: 1000
    }
  })





    event.custom({
    type: "mekanism:reaction",

    itemInput: {
      ingredient: {
        item: "minecraft:cobblestone"
      }
    },

    fluidInput: {
      fluid: "minecraft:lava",
      amount: 1000
    },

    gasInput: {
      gas: "mekanism:steam",
      amount: 1000
    },

    energyRequired: 1000,
    duration: 200,

    itemOutput: {
      item: "minecraft:iron_block"
    },

    gasOutput: {
      gas: "mekanism:steam",
      amount: 1
    }
  })





    event.custom({
    type: "mekanism:reaction",

    itemInput: {
      ingredient: {
        item: "create:zinc_nugget"
      }
    },
    fluidInput: {
      fluid: "minecraft:lava",
      amount: 1000
    },

    gasInput: {
      gas: "mekanism:steam",
      amount: 1000
    },

    energyRequired: 800,
    duration: 200,

    itemOutput: {
      item: "create:zinc_ingot"
    },

    gasOutput: {
      gas: "mekanism:steam",amount: 1
    }
  })

    event.custom({
    type: "mekanism:reaction",

    itemInput: {
      ingredient: {
        item: "minecraft:quartz"
      }
    },
    fluidInput: {
      fluid: "minecraft:water",
      amount: 1000
    },

    gasInput: {
      gas: "mekanism:oxygen",
      amount: 1000
    },

    energyRequired: 800,
    duration: 200,

    itemOutput: {
      item: "minecraft:prismarine_shard"
    },

    gasOutput: {
      gas: "mekanism:steam",amount: 1
    }
  })



  event.custom({
  type: "mekanism:metallurgic_infusing",

  itemInput: {
    ingredient: {
      item: "create:cinder_flour"
    }
  },

  chemicalInput: {
    amount: 1,
    tag: "mekanism:redstone"
  },

  output: {
    item: "minecraft:redstone",
    count: 1
  }
})
event.custom({
  type: "mekanism:crushing",

  input: {
    ingredient: {
      item: "minecraft:netherrack"
    }
  },

  output: {
    item: "create:cinder_flour",
    count: 2
  }
})

})



/*
kubejsテンプレート
変更するたびにマイクラの方で/reloadコマンドを打つこと
サイトにも同じことが書いてありますが
こっちの方がコピペしやすいと思います

必ず　recipe.jsに記述しましょう。
消えると困るのでバックアップはとっておきましょう。



Visual Studio Code を使用すると、エラーがわかりやすいです
必ず　インストールしましょう。　無料です！！！！！
Visual Studioと混同しないように

""（ダブルクォーテーション）と
''（シングルクォーテーション）は
どちらでも使用可能です。


https://azure.microsoft.com/ja-jp/products/visual-studio-code

1,コメント
次のように書いた場合その文は無視されます　どのようなレシピ追加などを
書いて置く際に便利です。

//コメント
/*コメント */

/*
2,レシピ追加を書く前に
3からはレシピ変更について説明しますが　それらを書く前には


ServerEvents.recipes(event => {}

と記述する必要があります。3以降はすべて｛｝の中に書きましょう。


3,既存レシピの削除
 event.remove({output:'削除したいアイテムのタグ'})
 レシピを指定せずすべて消します。この分を削除すればレシピは元通りになります。
 アイテムにカーソルを合わせると下の方に(minecraft:iron_ingot)のように書いてあります。

4,特定の既存レシピの削除
  event.remove({id: '削除したいレシピのID'})
  レシピを指定して消します。
  jeiを開いて完成品にカーソルを合わせるとレシピIDが書いてあります。

5,作業台レシピ追加（定型）
　  event.shaped('完成品のタグ', [


    'ABA',
    'BCB',
    'ABA'


  ], {
    A: '材料のタグa',
    B: '材料のタグb',
    C: '材料のタグc',
  })

    作業台でクラフトするレシピを追加します。ABAとか書いてある場所は
    書き換え可能です。　一番上をCBCにしても　CABにしても問題ありません。
    また必ずしもABCだけではいけないというわけではなく、DやE,1も使用可能です。
    2×2に収めれば、インベントリクラフトでも作れるようになります。
    完成品のタグ　の前に　8x　と入れると　8個出来上がります。
    event.shaped('（個数）x 完成品のタグ', [

6,作業台レシピ追加（不定形）

  event.shapeless(
    '完成品のタグ', 
    [
  
    '材料のタグ'
    ]


    
  )
　　形がぐちゃぐちゃでも材料がそろっていればクラフトできるレシピのことを
　　不定形レシピと呼びます。
　　個数指定などはさっきと同じ

　　mekanismやcreateの応用構文については今後アプデで書かれると思います。


*/